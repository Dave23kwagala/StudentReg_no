class Student:
    
    def __init__(self, Name, reg_no, Access_no):
        
        self.Name = Name
        self.reg_no = reg_no
        self.access_no = Access_no
        
    def display_Student_info(self):
        print(f"Student Name: {self.Name}")
        print(f"Regestration Number: {self.reg_no}")
        print(f"Access Number: {self.access_no}")
        
Student1 = Student("Gavamukulya Samson", "B32M13/023", "A98321")
Student2 = Student("Mukasa Allan", "M23B13/054", "A73453")
Student3 = Student("Kibalabye Joel", "B43M11/025", "A56833")
        
        
Student1.display_Student_info()
print()
Student2.display_Student_info()
print()
Student3.display_Student_info()
 

